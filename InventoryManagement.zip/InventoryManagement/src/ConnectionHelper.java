import java.sql.Connection;
import java.sql.DriverManager;

//THIS IS MY DATABASE CONNECTION HELPER PORTED FROM ANDROID STUDIO IT NEEDS THE jtds-1.3.1.jar IN ORDER
// TO FUNCTION CORRECTLY, THAT CAN BE DOWNLOADED @ https://sourceforge.net/projects/jtds/
public class ConnectionHelper {


    Connection connection;
    String ip, port, database, usernameD, passwordD;


    public Connection conclass() {
        ip = "TimothysDesktop";
        usernameD = "Manager";
        passwordD = "password";
        database = "GoldenIndia";
        port = "1433";

        Connection connection = null;
        String ConnectURL = null;

        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectURL = "jdbc:jtds:sqlserver://" + ip+"/" + database + ";user=" + usernameD + ";password=" + passwordD + ";";
            connection = DriverManager.getConnection(ConnectURL);
        }
        catch (Exception exception)
        {
            System.out.println("driver failed");
        }
        return connection;

    }


}
