

import java.sql.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samir
 */
public class DBConnection {
    static final String DB_URL ="jdbc:sqlserver://TimothysDesktop; databaseName=GoldenIndia"; 
    static final String USER ="Manager";
    static final String PASS ="password";
    public static Connection connectDB(){
        Connection conn = null;
        try {  
            
            conn =DriverManager.getConnection(DB_URL, USER, PASS);
            return conn;
        } catch(Exception ex){
            System.out.println("Connection Failed");
            
        }
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            System.out.println("Driver loaded."); 
    }catch(Exception ex){
            System.out.println("driver failed");
            return conn;
        }
        return null;
    }
}
        

