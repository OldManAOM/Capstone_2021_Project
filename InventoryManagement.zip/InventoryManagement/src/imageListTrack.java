import javax.swing.*;

public class imageListTrack {

    private int item_id;
    private String item_Name;
    private String description;
    private String manufacturer;
    private String UPC;
    private String size;
    private Double weight;
    private String flavor;
    private String price_Tier;
    private String category;
    private String promoted;
    private String style;
    private Double rate;
    
    public imageListTrack(int item_id, String item_Name, String description, String manufacturer, String UPC, String size, Double weight, String flavor, String price_Tier, String category, String promoted, String style, Double rate){
        this.item_id = item_id;
        this.item_Name = item_Name;
        this.description = description;
        this.manufacturer = manufacturer;
        this.UPC = UPC;
        this.size = size;
        this.weight = weight;
        this.flavor = flavor;
        this.price_Tier = price_Tier;
        this.category = category;
        this.promoted = promoted;
        this.style = style;
        this.rate = rate;
    }
    
    public int getItemID(){
        return item_id;
    }
    
    public String getItemName(){
        return item_Name;
    }
    
    public String getDescription(){
        return description;
    }
    
    public String getManufacturer(){
        return manufacturer;
    }
    
    public String getUPC(){
        return UPC;
    }
    
    public String getSize(){
        return size;
    }
    
    public Double getWeight(){
        return weight;
    }
    
    public String getFlavor(){
        return flavor;
    }
    
    public String getPriceTier(){
        return price_Tier;
    }
    
    public String getCategory(){
        return category;
    }
    
    public String getPromoted(){
        return promoted;
    }
    
    public String getStyle(){
        return style;
    }
    
    public Double getRate(){
        return rate;
    }
}
