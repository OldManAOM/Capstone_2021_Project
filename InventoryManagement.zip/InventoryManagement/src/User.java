
import java.util.Date;
import java.sql.Time;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Samir
 */
class User {
    private int Employee_ID;
    private Date Expected_Checkin_Date,Expected_Checkout_Date ;
    private Time Expected_Checkin_Time, Expected_Checkout_Time;
    public User(int Employee_ID, Date Expected_Checkin_Date,
            Time Expected_Checkin_Time,Date Expected_Checkout_Date, Time Expected_Checkout_Time){
        this.Employee_ID= Employee_ID;
        this.Expected_Checkin_Date = Expected_Checkin_Date;
        this.Expected_Checkout_Date = Expected_Checkout_Date;
        this.Expected_Checkin_Time = Expected_Checkin_Time;
        this.Expected_Checkout_Time = Expected_Checkout_Time;
}
    public int getEmployee_ID(){
        return Employee_ID;
    }
        public Date getExpected_Checkin_Date(){
        return Expected_Checkin_Date;
    }
       
        public Time getExpected_Checkin_Time(){
        return Expected_Checkin_Time;
    }
         public Date getExpected_Checkout_Date(){
        return Expected_Checkout_Date;
    }
        public Time getExpected_Checkout_Time(){
        return Expected_Checkout_Time;
    }
}
